import { Repository } from "./repository";
import { CredentialBroker } from "./credentials";
import { PluginRegistry } from "@taskasaur/platform/core/registry";
import { MessageRouter } from "@taskasaur/platform/core/messages";
import type { Principal } from "@taskasaur/platform/plugin-sdk";
export declare function services(): {
    repo: Repository;
    broker: () => CredentialBroker;
};
export declare function registryFor(repo: Repository, principal: Principal): PluginRegistry;
export declare function routerFor(repo: Repository, principal: Principal): Promise<MessageRouter>;
