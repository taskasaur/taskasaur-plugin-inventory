import { registerExtension } from "@taskasaur/platform/core/catalog";
import type { Database } from "./database";
export declare const pluginRoot: () => string;
export declare function packPlugin(directory: string, key: string): Promise<Buffer<ArrayBufferLike>>;
export declare function verifyPackage(bytes: Buffer, trust: Record<string, string>): Promise<{
    manifest: {
        id: string;
        description: string;
        name: string;
        version: string;
        platformApi: "^1.0.0";
        fieldSchemaApi: "^1.0.0";
        publisher: string;
        license: string;
        entrypoints: {
            browser?: string | undefined;
            server?: string | undefined;
            runner?: string | undefined;
        };
        ui: {
            mode: "none" | "shared";
            surfaces: string[];
            apiVersion?: string | undefined;
        };
        storage: {
            local: {
                mode: "none" | "dexie";
                collections: string[];
            };
        };
        permissions: string[];
        dependencies: string[];
        features: Record<string, {
            defaultEnabled: false;
        }>;
        sharedServices: {
            id: string;
            version: "^1";
            optional: boolean;
            when?: string | undefined;
        }[];
        provides: {
            commands: string[];
            events: string[];
        };
        consumes: {
            commands: string[];
            events: string[];
        };
        server?: {
            routes: {
                path: string;
                methods: ("GET" | "POST" | "PUT" | "DELETE")[];
                authentication: "workspace" | "plugin";
            }[];
            background: boolean;
            mutationHooks: boolean;
        } | undefined;
    };
    contracts: any;
    files: Record<string, Uint8Array<ArrayBufferLike>>;
    digest: string;
}>;
export declare function installedPackages(): Promise<Record<string, {
    version: string;
    digest: string;
    grants: string[];
    publicKey: string;
}>>;
export declare function installPackage(bytes: Buffer, trust: Record<string, string>, grants: string[], db?: Database): Promise<{
    id: string;
    version: string;
    digest: string;
}>;
type LoadedPackage = ReturnType<typeof registerExtension> & {
    directory: string;
    grants: string[];
    digest: string;
    browserDigest?: string;
};
export declare function loadPackageCatalog(): Promise<LoadedPackage[]>;
export {};
