import type { Repository } from "./repository";
import type { WorkflowSignal } from "@taskasaur/platform/plugin-sdk/device";
export declare function pendingSignals(repo: Repository, runId: string): Promise<WorkflowSignal[]>;
export declare function acknowledgeSignal(repo: Repository, runId: string, id: string): Promise<void>;
export type { WorkflowSignal } from "@taskasaur/platform/plugin-sdk/device";
