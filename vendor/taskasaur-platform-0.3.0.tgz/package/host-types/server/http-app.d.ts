export declare function handleRequest(request: Request): Promise<Response>;
