import type { Database } from "./database";
import { type Query } from "@taskasaur/platform/field-types";
import type { Principal, Mutation, ResourceRecord } from "@taskasaur/platform/plugin-sdk";
type ResourceRow = {
    id: string;
    workspace_id: string;
    owner_id: string;
    plugin_id: string;
    collection: string;
    revision: string | number;
    created_at: string | Date;
    updated_at: string | Date;
    deleted_at: string | Date | null;
} & Record<string, unknown>;
export declare class Repository {
    readonly db: Database;
    constructor(db: Database);
    featureEnabled(principal: Principal, id: string, feature: string): Promise<boolean>;
    requirePlugin(principal: Principal, id: string, tx?: Database): Promise<void>;
    createWorkspace(userId: string, name: string, id?: `${string}-${string}-${string}-${string}-${string}`): Promise<`${string}-${string}-${string}-${string}-${string}`>;
    membership(principal: Principal, write?: boolean, tx?: Database): Promise<string>;
    authorize(principal: Principal, id: string, write?: boolean, tx?: Database): Promise<ResourceRow>;
    private hydrate;
    get(principal: Principal, id: string): Promise<ResourceRecord>;
    list(principal: Principal, collection: string, query?: Query): Promise<ResourceRecord[]>;
    mutate(principal: Principal, mutation: Mutation, source?: "service" | "plugin"): Promise<ResourceRecord>;
    pull(principal: Principal, cursor: string): Promise<{
        records: ResourceRecord[];
        authorizedIds: string[];
        writableIds: string[];
        workspaceWrite: boolean;
        cursor: string;
        hasMore: boolean;
    }>;
}
export {};
