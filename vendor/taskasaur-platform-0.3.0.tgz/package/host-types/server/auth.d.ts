import type { Principal } from "@taskasaur/platform/plugin-sdk";
export declare function supabaseAuth(): import("@supabase/supabase-js").SupabaseClient<any, "public", "public", any, any>;
export declare function authenticatedUser(request: Request): Promise<import("@supabase/auth-js").User>;
export declare function principalFor(request: Request, workspaceId: string, pluginId: string): Promise<Principal>;
export declare function checkOrigin(request: Request): void;
