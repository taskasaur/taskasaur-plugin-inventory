import type { Repository } from "./repository";
export declare function processBackground(repo: Repository): Promise<void>;
