import { PluginHost } from "@taskasaur/platform/core/host";
import type { Principal } from "@taskasaur/platform/plugin-sdk";
import type { MessageRouter } from "@taskasaur/platform/core/messages";
import type { Repository } from "./repository";
export declare function serverPluginHost(repo: Repository, principal: Principal, router: MessageRouter): Promise<PluginHost>;
