import type { Principal } from "@taskasaur/platform/plugin-sdk";
import type { Repository } from "./repository";
export type CredentialSecret = {
    username?: string;
    password?: string;
    apiKey?: string;
    accessToken?: string;
    refreshToken?: string;
    expiresAt?: string;
    privateKey?: string;
    clientId?: string;
    clientSecret?: string;
    tokenEndpoint?: string;
};
export declare class CredentialBroker {
    private repository;
    private readonly key;
    constructor(repository: Repository, key: string);
    private encrypt;
    private decrypt;
    set(principal: Principal, id: string, secret: CredentialSecret): Promise<void>;
    use<T>(principal: Principal, id: string, pluginId: string, destination: string, action: string, operation: (secret: CredentialSecret) => Promise<T>): Promise<T>;
    revoke(principal: Principal, id: string): Promise<void>;
}
