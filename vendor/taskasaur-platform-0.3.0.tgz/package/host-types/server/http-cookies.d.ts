export declare function cookieJar(request: Request): {
    get: (name: string) => {
        value: string;
    } | undefined;
    set: (name: string, value: string, options?: {
        maxAge?: number;
        secure?: boolean;
        httpOnly?: boolean;
        sameSite?: string;
        path?: string;
    }) => void;
    delete: (name: string) => void;
};
export declare function withCookies(execute: () => Promise<Response>): Promise<Response>;
