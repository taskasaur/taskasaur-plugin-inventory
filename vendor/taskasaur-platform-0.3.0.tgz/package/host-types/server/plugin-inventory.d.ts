import type { Database } from "./database";
export declare function availablePlugins(force?: boolean): Promise<{
    name: string;
    schemaVersion: 1;
    publishers: Record<string, string>;
    plugins: {
        id: string;
        description: string;
        name: string;
        sha256: string;
        version: string;
        publisher: string;
        license: string;
        permissions: string[];
        dependencies: string[];
        grants: string[];
        downloadUrl: string;
        tags: string[];
        platforms: ("browser" | "server" | "runner" | "desktop" | "ios" | "android")[];
        repositoryUrl?: string | undefined;
        homepageUrl?: string | undefined;
        documentationUrl?: string | undefined;
    }[];
}>;
export declare function installInventoryPlugin(input: {
    id: string;
    version: string;
    sha256: string;
    grants: string[];
}, db?: Database): Promise<{
    id: string;
    version: string;
    digest: string;
}>;
