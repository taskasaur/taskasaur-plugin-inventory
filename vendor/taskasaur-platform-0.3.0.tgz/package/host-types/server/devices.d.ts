import type { Repository } from "./repository";
import type { Principal } from "@taskasaur/platform/plugin-sdk";
export declare const hashToken: (token: string) => string;
export declare class DeviceService {
    private repo;
    constructor(repo: Repository);
    createEnrollment(principal: Principal): Promise<{
        code: string;
        expiresAt: string;
    }>;
    enroll(code: string, name: string, platform: string, capabilities: string[], publicKey: string): Promise<{
        deviceId: `${string}-${string}-${string}-${string}-${string}`;
        token: string;
        workspaceId: string;
        userId: string;
        gatewayUrl: string;
    }>;
    authenticate(deviceId: string, token: string): Promise<{
        workspace_id: string;
        owner_id: string;
        lease_epoch: number;
    }>;
    heartbeat(deviceId: string, token: string): Promise<void>;
    connect(deviceId: string, token: string): Promise<{
        lease_epoch: number;
        workspace_id: string;
        owner_id: string;
    }>;
    revoke(principal: Principal, id: string): Promise<void>;
    terminalTicket(principal: Principal, deviceId: string): Promise<{
        sessionId: `${string}-${string}-${string}-${string}-${string}`;
        ticket: string;
        gatewayUrl: string;
    }>;
}
