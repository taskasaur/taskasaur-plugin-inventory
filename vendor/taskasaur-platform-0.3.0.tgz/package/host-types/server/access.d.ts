import type { Repository } from "./repository";
import type { Principal } from "@taskasaur/platform/plugin-sdk";
export declare class AccessService {
    private repo;
    constructor(repo: Repository);
    members(actor: Principal): Promise<Record<string, unknown>[]>;
    addMember(actor: Principal, email: string, role: string): Promise<{
        userId: string;
    }>;
    removeMember(actor: Principal, userId: string): Promise<{
        ok: boolean;
    }>;
    grants(actor: Principal, resourceId: string): Promise<Record<string, unknown>[]>;
    grant(actor: Principal, resourceId: string, subjectId: string, role: string | null, expiresAt: string | null): Promise<{
        ok: boolean;
    }>;
}
