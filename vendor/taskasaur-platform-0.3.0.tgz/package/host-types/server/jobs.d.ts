import { Repository } from "./repository";
import type { Principal, ResourceRecord } from "@taskasaur/platform/plugin-sdk";
import type { Value } from "@taskasaur/platform/field-types";
type JobPayload = {
    pluginId: string;
    command: string;
    input: Value;
    operationId: string;
    intervalSeconds?: number;
};
export type ClaimedJob = {
    record: ResourceRecord;
    actor: Principal;
    owner: string;
    epoch: string;
    payload: JobPayload;
};
export declare class JobService {
    private repo;
    constructor(repo: Repository);
    enqueue(actor: Principal, command: string, input: Value, options?: {
        operationId?: string;
        dueAt?: string;
        intervalSeconds?: number;
    }): Promise<ResourceRecord>;
    cancel(actor: Principal, id: string): Promise<void>;
    claim(owner: string): Promise<ClaimedJob | undefined>;
    settle(job: ClaimedJob, error?: unknown): Promise<void>;
}
export {};
