import type { Repository } from "./repository";
import type { Principal, PluginEvent } from "@taskasaur/platform/plugin-sdk";
export declare function publishEvent(repo: Repository, actor: Principal, event: PluginEvent): Promise<void>;
export declare function pullEvents(repo: Repository, actor: Principal, cursor: string): Promise<{
    events: PluginEvent[];
    cursor: string;
    hasMore: boolean;
}>;
