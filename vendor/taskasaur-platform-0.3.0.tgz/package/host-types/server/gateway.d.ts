import { type WebSocket } from "ws";
export declare function startGateway(port?: number): {
    server: import("http").Server<typeof import("http").IncomingMessage, typeof import("http").ServerResponse>;
    wss: import("ws").Server<typeof WebSocket, typeof import("http").IncomingMessage>;
    stop: () => void;
};
