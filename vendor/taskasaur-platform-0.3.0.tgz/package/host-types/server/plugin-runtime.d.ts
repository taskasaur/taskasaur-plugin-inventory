import { Repository } from "./repository";
import * as fields from "@taskasaur/platform/field-types";
import type { Principal, Mutation, ResourceRecord } from "@taskasaur/platform/plugin-sdk";
export declare function serverAdapter(repo: Repository, principal?: Principal): {
    repo: Repository;
    principal: Principal | undefined;
    field: typeof fields.field;
    require: (id: string) => any;
};
export interface MutationHook {
    repo: Repository;
    principal: Principal;
    mutation: Mutation;
    data: Record<string, fields.Value>;
    schema: fields.RecordSchema;
    record?: ResourceRecord;
}
export declare function pluginHttp(request: Request, path: string, context: {
    repo: Repository;
    principal?: Principal;
}, authentication: "workspace" | "plugin"): Promise<Response | undefined>;
export declare function pluginTick(repo: Repository, workspaceId: string): Promise<void>;
export declare function pluginMutation(phase: "beforeMutation" | "afterMutation", context: MutationHook): Promise<void>;
