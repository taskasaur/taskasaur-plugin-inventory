type Context = {
    params: Promise<{
        path: string[];
    }>;
};
declare function handle(request: Request, context: Context): Promise<Response>;
export declare const GET: typeof handle, POST: typeof handle, PUT: typeof handle, DELETE: typeof handle;
export {};
