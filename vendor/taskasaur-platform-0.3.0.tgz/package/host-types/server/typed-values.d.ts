import { type Field, type Value } from "@taskasaur/platform/field-types";
import type { Database } from "./database";
export declare const valueTable: (field: Pick<Field, "pgType" | "array">) => string;
export declare function migrateTypedValues(db: Database): Promise<void>;
export declare function writeTypedValues(db: Database, rowId: string, tableId: string, columns: unknown, values: Record<string, Value>): Promise<void>;
export declare function readTypedValues(db: Database, rowId: string, columns: unknown): Promise<Record<string, Value>>;
