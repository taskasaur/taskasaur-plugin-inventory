export interface Database {
    query<T extends Record<string, unknown> = Record<string, unknown>>(sql: string, values?: unknown[]): Promise<{
        rows: T[];
        rowCount?: number | null;
    }>;
    transaction<T>(fn: (db: Database) => Promise<T>): Promise<T>;
}
export declare function database(): Database;
export declare function closeDatabase(): Promise<void>;
