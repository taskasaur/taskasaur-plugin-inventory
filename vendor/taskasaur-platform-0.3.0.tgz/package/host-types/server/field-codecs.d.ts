import { type Field, type Value } from "@taskasaur/platform/field-types";
export declare function encodeSqlField(field: Field, value: Value): unknown;
export declare function decodeSqlField(field: Field, value: unknown): Value;
