import { Repository } from "./repository";
import type { Principal } from "@taskasaur/platform/plugin-sdk";
export declare class FileService {
    private repo;
    constructor(repo: Repository);
    upload(principal: Principal, fileId: string, bytes: Buffer, mediaType: string, parentId: string | null, id: string): Promise<{
        versionId: string;
        record: import("@taskasaur/platform/plugin-sdk").ResourceRecord;
    }>;
    download(principal: Principal, fileId: string, versionId?: string): Promise<Blob>;
}
